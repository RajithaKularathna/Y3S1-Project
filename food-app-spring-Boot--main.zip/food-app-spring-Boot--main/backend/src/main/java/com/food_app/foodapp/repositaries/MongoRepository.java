package com.food_app.foodapp.repositaries;

public class MongoRepository<T1, T2> {

}

package com.food_app.foodapp.model;

public class Notifcation {
    
}

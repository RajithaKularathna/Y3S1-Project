export default class User {
    constructor(id, username, email, firstName, lastName, profilePictureImageUrl, address, mobileNumber) {
      this.id = id;
      this.username = username;
      this.email = email;
      this.firstName = firstName;
      this.lastName = lastName;
      this.profilePictureImageUrl = profilePictureImageUrl;
      this.address = address;
      this.mobileNumber = mobileNumber;
    }
  }
  
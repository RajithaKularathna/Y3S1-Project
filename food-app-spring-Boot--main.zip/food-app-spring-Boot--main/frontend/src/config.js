const baseUrl = "http://localhost:8080/api"
const appLogo = "https://th.bing.com/th/id/OIP.yNWyNxlFmhm0lvA_SiG_RgAAAA?pid=ImgDet&rs=1"
const noDp = "https://th.bing.com/th/id/R.c98530977183534ed0e49e6db725bd7d?rik=2qJXoi1QKl%2b7Iw&pid=ImgRaw&r=0"
export default {baseUrl,appLogo,noDp}
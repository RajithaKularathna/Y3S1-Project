import { initializeApp } from 'firebase/app';

const firebaseConfig =
{
  apiKey: "AIzaSyCJJRi7Iah45dRo4-JdJ6zDD5RwDc1UMT4",
  authDomain: "microtech-8704a.firebaseapp.com",
  projectId: "microtech-8704a",
  storageBucket: "microtech-8704a.appspot.com",
  messagingSenderId: "370666785649",
  appId: "1:370666785649:web:f80f33001b52e457f004d0",
  measurementId: "G-CLYR3GFYBC"



}  //...


const app = initializeApp(firebaseConfig);


export default  app





